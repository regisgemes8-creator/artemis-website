import { useState } from 'react';

interface Module {
  name: string;
  description: string;
  enabled: boolean;
  category: string;
}

function App() {
  const [modules, setModules] = useState<Module[]>([
    // Combat
    {
      name: 'CrystalAura',
      description: 'Automatically places and breaks end crystals',
      enabled: true,
      category: 'Combat'
    },
    {
      name: 'AutoTotem',
      description: 'Automatically equips totems of undying',
      enabled: true,
      category: 'Combat'
    },
    {
      name: 'Surround',
      description: 'Places obsidian around you for protection',
      enabled: false,
      category: 'Combat'
    },
    {
      name: 'KillAura',
      description: 'Automatically attacks nearby entities',
      enabled: false,
      category: 'Combat'
    },
    {
      name: 'AntiCrystal',
      description: 'Prevents crystal damage to you',
      enabled: false,
      category: 'Combat'
    },
    {
      name: 'AutoTrap',
      description: 'Automatically traps enemies in obsidian',
      enabled: false,
      category: 'Combat'
    },
    {
      name: 'AntiTrap',
      description: 'Removes armor stands, minecarts, and chests to escape traps',
      enabled: true,
      category: 'Combat'
    },
    // Render
    {
      name: 'StorageESP',
      description: 'Shows all chests, shulkers, and storage blocks',
      enabled: true,
      category: 'Render'
    },
    {
      name: 'HoleESP',
      description: 'Highlights safe holes for crystal PVP',
      enabled: true,
      category: 'Render'
    },
    {
      name: 'BaseFinder',
      description: 'Automatically detects and marks player bases',
      enabled: false,
      category: 'Render'
    },
    {
      name: 'ChunkFinder',
      description: 'Locates and highlights specific chunks',
      enabled: false,
      category: 'Render'
    },
    {
      name: 'NewChunks',
      description: 'Highlights newly generated chunks',
      enabled: true,
      category: 'Render'
    },
    {
      name: 'ChunkBorders',
      description: 'Renders chunk borders and boundaries',
      enabled: false,
      category: 'Render'
    },
    {
      name: 'PlayerESP',
      description: 'Shows players through walls with info',
      enabled: true,
      category: 'Render'
    },
    {
      name: 'EntityESP',
      description: 'Highlights all entities and mobs',
      enabled: false,
      category: 'Render'
    },
    {
      name: 'Tracers',
      description: 'Draws lines to players and entities',
      enabled: false,
      category: 'Render'
    },
    {
      name: 'Nametags',
      description: 'Enhanced nametags with health and distance',
      enabled: true,
      category: 'Render'
    },
    {
      name: 'BlockESP',
      description: 'Highlights specific blocks (ores, spawners, etc)',
      enabled: true,
      category: 'Render'
    },
    {
      name: 'CrystalESP',
      description: 'Renders end crystal positions and damage',
      enabled: true,
      category: 'Render'
    },
    // Movement
    {
      name: 'Speed',
      description: 'Increases movement speed',
      enabled: false,
      category: 'Movement'
    },
    {
      name: 'Flight',
      description: 'Allows you to fly',
      enabled: false,
      category: 'Movement'
    },
    {
      name: 'ElytraFly',
      description: 'Enhanced elytra flight mechanics',
      enabled: false,
      category: 'Movement'
    },
    {
      name: 'Step',
      description: 'Walk up blocks like stairs',
      enabled: false,
      category: 'Movement'
    },
    // Player
    {
      name: 'AutoArmor',
      description: 'Automatically equips best armor',
      enabled: true,
      category: 'Player'
    },
    {
      name: 'NoFall',
      description: 'Prevents fall damage',
      enabled: false,
      category: 'Player'
    },
    {
      name: 'FastUse',
      description: 'Use items faster (XP, crystals, etc)',
      enabled: true,
      category: 'Player'
    },
    {
      name: 'AutoEat',
      description: 'Automatically eats food when hungry',
      enabled: true,
      category: 'Player'
    },
    {
      name: 'NoRotate',
      description: 'Prevents server from rotating your head',
      enabled: true,
      category: 'Player'
    }
  ]);

  const toggleModule = (index: number) => {
    setModules(modules.map((module, i) => 
      i === index ? { ...module, enabled: !module.enabled } : module
    ));
  };

  const categories = ['Combat', 'Render', 'Movement', 'Player'];

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-950 via-gray-900 to-blue-950 text-white">
      {/* Header */}
      <header className="border-b border-cyan-500/30 bg-black/40 backdrop-blur-sm">
        <div className="container mx-auto px-6 py-8">
          <h1 className="text-6xl font-bold text-center">
            <span className="bg-gradient-to-r from-cyan-400 via-blue-500 to-cyan-400 bg-clip-text text-transparent drop-shadow-[0_0_30px_rgba(6,182,212,0.5)]">
              ARTEMIS
            </span>
          </h1>
          <p className="text-center text-cyan-400 mt-3 text-lg tracking-wider">
            BASEFINDING CLIENT FOR DONUT SMP
          </p>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-6 py-12">
        {/* Bypass Badge */}
        <div className="flex justify-center mb-12">
          <div className="bg-gradient-to-r from-cyan-500/20 to-blue-500/20 border border-cyan-400/50 rounded-lg px-8 py-4 shadow-[0_0_30px_rgba(6,182,212,0.3)]">
            <p className="text-cyan-300 text-lg font-semibold flex items-center gap-3">
              <span className="inline-block w-3 h-3 bg-cyan-400 rounded-full animate-pulse shadow-[0_0_10px_rgba(6,182,212,0.8)]"></span>
              ✓ FULLY UNDETECTABLE - BYPASSES DONUT SMP ANTICHEAT
            </p>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex justify-center gap-6 mb-16">
          <a
            href="https://google.com"
            className="group relative px-12 py-4 bg-gradient-to-r from-cyan-600 to-blue-600 rounded-lg font-bold text-xl transition-all duration-300 hover:shadow-[0_0_40px_rgba(6,182,212,0.6)] hover:scale-105 overflow-hidden"
          >
            <div className="absolute inset-0 bg-gradient-to-r from-cyan-400 to-blue-400 opacity-0 group-hover:opacity-20 transition-opacity"></div>
            <span className="relative">DOWNLOAD</span>
          </a>
          <button
            className="group relative px-12 py-4 bg-gradient-to-r from-blue-900/50 to-cyan-900/50 border-2 border-cyan-500/50 rounded-lg font-bold text-xl transition-all duration-300 hover:border-cyan-400 hover:shadow-[0_0_30px_rgba(6,182,212,0.4)] hover:scale-105"
          >
            <span className="relative">DISCORD</span>
          </button>
        </div>

        {/* Modules Section */}
        <div className="max-w-6xl mx-auto">
          <h2 className="text-4xl font-bold text-cyan-400 mb-8 text-center drop-shadow-[0_0_20px_rgba(6,182,212,0.5)]">
            MODULES
          </h2>

          {categories.map(category => (
            <div key={category} className="mb-10">
              <h3 className="text-2xl font-semibold text-cyan-300 mb-4 flex items-center gap-3">
                <span className="w-2 h-2 bg-cyan-400 rounded-full shadow-[0_0_10px_rgba(6,182,212,0.8)]"></span>
                {category}
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {modules
                  .filter(module => module.category === category)
                  .map((module) => {
                    const actualIndex = modules.findIndex(m => m.name === module.name);
                    return (
                      <div
                        key={module.name}
                        onClick={() => toggleModule(actualIndex)}
                        className={`p-5 rounded-lg border cursor-pointer transition-all duration-300 ${
                          module.enabled
                            ? 'bg-cyan-500/10 border-cyan-400/60 shadow-[0_0_20px_rgba(6,182,212,0.2)] hover:shadow-[0_0_30px_rgba(6,182,212,0.4)]'
                            : 'bg-gray-900/40 border-gray-700/50 hover:border-gray-600'
                        }`}
                      >
                        <div className="flex items-center justify-between mb-2">
                          <h4 className={`text-lg font-semibold ${
                            module.enabled ? 'text-cyan-300' : 'text-gray-400'
                          }`}>
                            {module.name}
                          </h4>
                          <div className={`w-12 h-6 rounded-full relative transition-all duration-300 ${
                            module.enabled ? 'bg-cyan-500 shadow-[0_0_15px_rgba(6,182,212,0.6)]' : 'bg-gray-700'
                          }`}>
                            <div className={`absolute top-1 w-4 h-4 bg-white rounded-full transition-all duration-300 ${
                              module.enabled ? 'right-1' : 'left-1'
                            }`}></div>
                          </div>
                        </div>
                        <p className={`text-sm ${
                          module.enabled ? 'text-cyan-200/70' : 'text-gray-500'
                        }`}>
                          {module.description}
                        </p>
                      </div>
                    );
                  })}
              </div>
            </div>
          ))}
        </div>

        {/* Footer */}
        <div className="mt-20 text-center">
          <p className="text-gray-500 text-sm">
            Artemis Client v2.1 | Built for Basefinding
          </p>
          <p className="text-cyan-400/50 text-xs mt-2">
            Optimized for Donut SMP
          </p>
        </div>
      </main>
    </div>
  );
}

export default App;
